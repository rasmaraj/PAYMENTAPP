﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;

namespace APP.Controllers
{
    public class HomeController : Controller
    {
            string Baseurl = "https://localhost:44322/api/carddetails/";
            public async Task<ActionResult> Index()
            {
                var _response = new APP.Component.Models.Model_Response();
                using (var client = new HttpClient())
                {
                    client.BaseAddress = new Uri(Baseurl);
                    client.DefaultRequestHeaders.Clear();
                    client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                    client.DefaultRequestHeaders.Add("Authorization", "Basic dGVzdDp0ZXN0QDEyMw==");
                    HttpResponseMessage Res = await client.GetAsync($"{Baseurl}getAll?key=c18BnRNJiHN40ixNVcFQ");
                    if (Res.IsSuccessStatusCode)
                    {
                       
                        var Response = Res.Content.ReadAsStringAsync().Result;
                    _response = JsonConvert.DeserializeObject<APP.Component.Models.Model_Response>(Response);
                    }
                //returning the employee list to view
                var M =_response.SuccessResponse.Count!=0?(List<APP.Component.Models.Model_BankCard>)_response.SuccessResponse:new List<APP.Component.Models.Model_BankCard>();

                    return View(M);
                }
            }
        public async Task<ActionResult> update(int PaymentID)
        {

            if (TempData["error"]!=null)
            {
                if (TempData["error"] is Tuple<APP.Component.Models.Model_BankCard, HashSet<string>> T)
                {
                    ViewBag.Error =string.Join("<br/>",T.Item2.ToList());
                    ViewBag.PaymentID = T.Item1.PaymentDetailsID;
                    return View(T.Item1);
                }
            }
            
            string Url = $"{Baseurl}get?key=c18BnRNJiHN40ixNVcFQ";
            var _response = new APP.Component.Models.Model_ResponseCURD();
            var M = new APP.Component.Models.Model_BankCard();
            M.PaymentDetailsID =$"{PaymentID}";
            var JSON = APP.Component.Helper.Helper_Common.Helper_JSON_String.JSON_String(M);
            using (HttpClient httpClient = new HttpClient())
            {
                using (HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, Url))
                {
                    requestMessage.Content = new StringContent(JSON, Encoding.UTF8, "application/json");
                    requestMessage.Headers.Add("Authorization", "Basic dGVzdDp0ZXN0QDEyMw==");
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    using (HttpResponseMessage response = await httpClient.SendAsync(requestMessage))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var productJsonString = await response.Content.ReadAsStringAsync();
                            _response = JsonConvert.DeserializeObject<APP.Component.Models.Model_ResponseCURD>(productJsonString);
                        }
                    }
                }
                var res = _response.SuccessResponse != null ? (APP.Component.Models.Model_BankCard)_response.SuccessResponse : null;
                if (res != null)
                {
                    ViewBag.PaymentID = res.PaymentDetailsID;
                    return View(res);
                }
            }
            return RedirectToAction("Index");
        }
        public async Task<ActionResult> process_update(int PID)
        {
            string Url = $"{Baseurl}update?key=c18BnRNJiHN40ixNVcFQ";
            var _response = new APP.Component.Models.Model_ResponseCURD();
            var M = new APP.Component.Models.Model_BankCard();
            M.PaymentDetailsID = $"{PID}";
            M.CardOwner = $"{Request["Txt_CardOwner"]}";
            M.CardNumber = $"{Request["Txt_CardNumber"]}";
            M.ExporationDate = $"{Request["Txt_ExporationDate"]}";
            M.SecurityCode = $"{Request["Txt_SecurityCode"]}";
            var JSON = APP.Component.Helper.Helper_Common.Helper_JSON_String.JSON_String(M);
            using (HttpClient httpClient = new HttpClient())
            {
                using (HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, Url))
                {
                    requestMessage.Content = new StringContent(JSON, Encoding.UTF8, "application/json");
                    requestMessage.Headers.Add("Authorization", "Basic dGVzdDp0ZXN0QDEyMw==");
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    using (HttpResponseMessage response = await httpClient.SendAsync(requestMessage))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var productJsonString = await response.Content.ReadAsStringAsync();
                            _response = JsonConvert.DeserializeObject<APP.Component.Models.Model_ResponseCURD>(productJsonString);
                        }
                    }
                }
                var error = _response.FailureCount != 0 ? (HashSet<string>)_response.FailureMessage : null;
                if (error != null)
                {
                    TempData["error"] =new Tuple< APP.Component.Models.Model_BankCard, HashSet<string>>(M,error);
                  return  RedirectToAction("update", new { PaymentID = PID });
                }
            }
            return RedirectToAction("Index");
        }
        public async Task<ActionResult> create()
        {

            if (TempData["error"] != null)
            {
                if (TempData["error"] is Tuple<APP.Component.Models.Model_BankCard, HashSet<string>> T)
                {
                    ViewBag.Error = string.Join("<br/>", T.Item2.ToList());
                    return View(T.Item1);
                }
            }
            return View();
        }
        public async Task<ActionResult> process_register()
        {
            string Url = $"{Baseurl}register?key=c18BnRNJiHN40ixNVcFQ";
            var _response = new APP.Component.Models.Model_ResponseCURD();
            var M = new APP.Component.Models.Model_BankCard();
            M.PaymentDetailsID = $"0";
            M.CardOwner = $"{Request["Txt_CardOwner"]}";
            M.CardNumber = $"{Request["Txt_CardNumber"]}";
            M.ExporationDate = $"{Request["Txt_ExporationDate"]}";
            M.SecurityCode = $"{Request["Txt_SecurityCode"]}";
            var JSON = APP.Component.Helper.Helper_Common.Helper_JSON_String.JSON_String(M);
            using (HttpClient httpClient = new HttpClient())
            {
                using (HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, Url))
                {
                    requestMessage.Content = new StringContent(JSON, Encoding.UTF8, "application/json");
                    requestMessage.Headers.Add("Authorization", "Basic dGVzdDp0ZXN0QDEyMw==");
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    using (HttpResponseMessage response = await httpClient.SendAsync(requestMessage))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var productJsonString = await response.Content.ReadAsStringAsync();
                            _response = JsonConvert.DeserializeObject<APP.Component.Models.Model_ResponseCURD>(productJsonString);
                        }
                    }
                }
                var error = _response.FailureCount != 0 ? (HashSet<string>)_response.FailureMessage : null;
                if (error != null)
                {
                    TempData["error"] = new Tuple<APP.Component.Models.Model_BankCard, HashSet<string>>(M, error);
                    return RedirectToAction("create");
                }
            }
            return RedirectToAction("Index");
        }
    }

    }