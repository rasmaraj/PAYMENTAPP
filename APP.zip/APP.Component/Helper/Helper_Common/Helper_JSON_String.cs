﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APP.Component.Helper.Helper_Common
{
   public class Helper_JSON_String
    {
        public static string JSON_String(Models.Model_BankCard Model_JSON)
        {
            string _attributeData = JsonConvert.SerializeObject(Model_JSON);
            return _attributeData;
        }
    }
}
