﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace APP.Component.Helper.Helper_Common
{
   public class Helper_API
    {
        public static async Task<Models.Model_Response> Post_V2(string _JSON, string URL)
        {
            Models.Model_Response Result = null;
            using (HttpClient httpClient = new HttpClient())
            {
                string requestUri = URL;
                using (HttpRequestMessage requestMessage = new HttpRequestMessage(HttpMethod.Post, requestUri))
                {
                    requestMessage.Headers.Add("User-Agent", "DANXSchedular");
                    requestMessage.Headers.Add("api_key", "oSAsI6BwMr3TTPuqj76z5aBFXcARI6Rv");
                    requestMessage.Content = new StringContent(_JSON, Encoding.UTF8, "application/json");
                    ServicePointManager.SecurityProtocol = SecurityProtocolType.Tls12;
                    using (HttpResponseMessage response = await httpClient.SendAsync(requestMessage))
                    {
                        if (response.IsSuccessStatusCode)
                        {
                            var productJsonString = await response.Content.ReadAsStringAsync();
                            Result = JsonConvert.DeserializeObject<Models.Model_Response>(productJsonString);
                        }
                    }
                }
            }
            return Result;
        }

    }
}
