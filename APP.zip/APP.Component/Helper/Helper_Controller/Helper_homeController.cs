﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace APP.Component.Helper.Helper_Controller
{
    public class Helper_homeController
    {


        //public static List<Models.Model_JSON_BankCard> Index()
        //{


        //}



    }
}
