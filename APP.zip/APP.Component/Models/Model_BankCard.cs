﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace APP.Component.Models
{
    public class Model_BankCard
    {
        public string PaymentDetailsID { get; set; }
        public string CardOwner { get; set; }
        public string CardNumber { get; set; }
        public string ExporationDate { get; set; }
        public string SecurityCode { get; set; }
    }
}