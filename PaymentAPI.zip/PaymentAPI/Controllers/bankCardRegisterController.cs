﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web;
using System.Web.Http;

namespace PaymentAPI.Controllers
{
    [RoutePrefix("api/carddetails")]
    public class bankCardRegisterController : ApiController
    {

        [HttpPost]
        [Route("get")]
        public HttpResponseMessage getBankCard(string key, object S)
        {
            HttpResponseMessage result = null;
            var R = new ApplicationComponent.PaymentAPI.Model.Model_Response();
            try
            {

                result = new HttpResponseMessage(HttpStatusCode.OK);
                var httpContext = HttpContext.Current;
                string authHeader = httpContext != null ? httpContext.Request.Headers["Authorization"] : "";
                R = ApplicationComponent.PaymentAPI.Helper.Helper_PaymentAPI.Helper_Controller_BankCardRegister.collectCard(key, S, authHeader);

            }
            catch (Exception ex)
            {
                result = new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
                R.FailureCount = 1;
                var E = new HashSet<string>();
                E.Add(ex.Message);
                R.FailureMessage = E;
                R.ReferenceKey = "";
                R.SuccessCount = 0;
                R.SuccessResponse = null;
            }
            result.Content = new StringContent(JsonConvert.SerializeObject(R));
            result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return result;
        }
        [HttpGet]
        [Route("getall")]
        public HttpResponseMessage getallBankCard(string key)
        {
            HttpResponseMessage result = null;
            var R = new ApplicationComponent.PaymentAPI.Model.Model_ResponseCollectAll();
            try
            {

                result = new HttpResponseMessage(HttpStatusCode.OK);
                var httpContext = HttpContext.Current;
                string authHeader = httpContext != null ? httpContext.Request.Headers["Authorization"] : "";
                R = ApplicationComponent.PaymentAPI.Helper.Helper_PaymentAPI.Helper_Controller_BankCardRegister.collectAll(key,authHeader);
            }
            catch (Exception ex)
            {
                result = new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
                var E = new HashSet<string>();
                E.Add(ex.Message);
            }
            result.Content = new StringContent(JsonConvert.SerializeObject(R));
            result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return result;
        }

        [HttpPost]
        [Route("register")]
        public HttpResponseMessage registerBankCard(string key, object S)
        {
            HttpResponseMessage result = null;
            var R = new ApplicationComponent.PaymentAPI.Model.Model_Response();
            try
            {

                result = new HttpResponseMessage(HttpStatusCode.OK);
                var httpContext = HttpContext.Current;
                string authHeader = httpContext != null ? httpContext.Request.Headers["Authorization"] : "";
                R = ApplicationComponent.PaymentAPI.Helper.Helper_PaymentAPI.Helper_Controller_BankCardRegister.createCard(key, S, authHeader);
                
            }
            catch (Exception ex)
            {
                result = new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
                R.FailureCount = 1;
                var E = new HashSet<string>();
                E.Add(ex.Message);
                R.FailureMessage = E;
                R.ReferenceKey = "";
                R.SuccessCount = 0;
                R.SuccessResponse = null;
            }
            result.Content = new StringContent(JsonConvert.SerializeObject(R));
            result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return result;
        }

        [HttpPost]
        [Route("update")]
        public HttpResponseMessage updateBankCard(string key, object S)
        {
            HttpResponseMessage result = null;
            var R = new ApplicationComponent.PaymentAPI.Model.Model_Response();
            try
            {

                result = new HttpResponseMessage(HttpStatusCode.OK);
                var httpContext = HttpContext.Current;
                string authHeader = httpContext != null ? httpContext.Request.Headers["Authorization"] : "";
                R = ApplicationComponent.PaymentAPI.Helper.Helper_PaymentAPI.Helper_Controller_BankCardRegister.updateCard(key, S, authHeader);

            }
            catch (Exception ex)
            {
                result = new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
                R.FailureCount = 1;
                var E = new HashSet<string>();
                E.Add(ex.Message);
                R.FailureMessage = E;
                R.ReferenceKey = "";
                R.SuccessCount = 0;
                R.SuccessResponse = null;
            }
            result.Content = new StringContent(JsonConvert.SerializeObject(R));
            result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return result;
        }
        [HttpPost]
        [Route("delete")]
        public HttpResponseMessage deleteBankCard(string key, object S)
        {
            HttpResponseMessage result = null;
            var R = new ApplicationComponent.PaymentAPI.Model.Model_Response();
            try
            {

                result = new HttpResponseMessage(HttpStatusCode.OK);
                var httpContext = HttpContext.Current;
                string authHeader = httpContext != null ? httpContext.Request.Headers["Authorization"] : "";
                R = ApplicationComponent.PaymentAPI.Helper.Helper_PaymentAPI.Helper_Controller_BankCardRegister.deleteCard(key, S, authHeader);

            }
            catch (Exception ex)
            {
                result = new HttpResponseMessage(System.Net.HttpStatusCode.BadRequest);
                R.FailureCount = 1;
                var E = new HashSet<string>();
                E.Add(ex.Message);
                R.FailureMessage = E;
                R.ReferenceKey = "";
                R.SuccessCount = 0;
                R.SuccessResponse = null;
            }
            result.Content = new StringContent(JsonConvert.SerializeObject(R));
            result.Content.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue("application/json");
            return result;
        }
    }
}
