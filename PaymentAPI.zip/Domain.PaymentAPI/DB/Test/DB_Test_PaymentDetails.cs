﻿using Domain.PaymentAPI.Provider;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.PaymentAPI.DB.Test
{
   public class DB_PaymentDetails
    {
		static string Connectionstring = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Test;";
		public static List<DAO.Test.PaymentDetails> Get_byPRocessState(int ProcessState)
		{
			var result = new List<DAO.Test.PaymentDetails>();
			using (SqlConnection Connection = new SqlConnection(Connectionstring))
			{
				string cmdText = "SELECT s.* FROM  PaymentDetails s with(Nolock) where Process_State=@Process_State";
				using (SqlCommand Command = new SqlCommand(cmdText, Connection))
				{
					Connection.Open();
					Command.Parameters.AddWithValue("@Process_State", ProcessState);
					using (SqlDataReader reader = Command.ExecuteReader())
					{
						while (reader.Read())
						{
							result.Add(FillObject(reader));
						}
					}
				}
			}
			return result;
		}
		public static List<DAO.Test.PaymentDetails> Get_ByCardNumber(string CardNumber)
        {
			var result = new List<DAO.Test.PaymentDetails>();
			using (SqlConnection Connection = new SqlConnection(Connectionstring))
			{
				string cmdText = "SELECT s.* FROM  PaymentDetails s with(Nolock) where CardNumber=@CardNumber ";
				using (SqlCommand Command = new SqlCommand(cmdText, Connection))
				{
					Connection.Open();
					Command.Parameters.AddWithValue("@CardNumber", CardNumber);
					using (SqlDataReader reader = Command.ExecuteReader())
					{
						while (reader.Read())
						{
							result.Add(FillObject(reader));
						}
					}
				}
			}
			return result;
		}
		public static List<DAO.Test.PaymentDetails> Get(HashSet<int> PaymentDetailsIDs)
		{
			var result = new List<DAO.Test.PaymentDetails>();
			using (SqlConnection Connection = new SqlConnection(Connectionstring))
			{
				string cmdText = "SELECT s.* FROM  PaymentDetails s with(Nolock) " +
								 " inner join @PaymentDetailsIDs i on s.PaymentDetailsID=i.IntegerValue ";
				using (SqlCommand Command = new SqlCommand(cmdText, Connection))
				{
					Connection.Open();
					Command.Parameters.Add(Custom_SqlParameter.Get_Parameter(PaymentDetailsIDs, "@PaymentDetailsIDs"));
					using (SqlDataReader reader = Command.ExecuteReader())
					{
						while (reader.Read())
						{
							result.Add(FillObject(reader));
						}
					}
				}
			}
			return result;
		}

		public static List<DAO.Test.PaymentDetails> Get()
		{
			var result = new List<DAO.Test.PaymentDetails>();
			using (SqlConnection Connection = new SqlConnection(Connectionstring))
			{
				string cmdText = "SELECT * FROM  PaymentDetails  with(Nolock)";
				using (SqlCommand Command = new SqlCommand(cmdText, Connection))
				{
					Connection.Open();
					using (SqlDataReader reader = Command.ExecuteReader())
					{
						while (reader.Read())
						{
							result.Add(FillObject(reader));
						}
					}
				}
			}
			return result;
		}
		public static int Insert(DAO.Test.PaymentDetails O)
		{
			int Result = -1;
			using (SqlConnection Connection = new SqlConnection(Connectionstring))
			{
				string cmdText = " insert into PaymentDetails(CardOwner,CardNumber,ExporationDate,SecurityCode,EDI,ExportedAt,Process_State)  " +
								 " output 'CRE',@EventDate,inserted.PaymentDetailsID,inserted.CardOwner,inserted.CardNumber,inserted.ExporationDate, " +
								 " inserted.SecurityCode,inserted.EDI,inserted.EXportedAt,inserted.Process_State into Log_PaymentDetails(Event, EventDate, " +
								 " PaymentDetailsID, CardOwner, CardNumber, ExporationDate, SecurityCode, EDI, EXportedAt, Process_State) " +
								 " values(@CardOwner,@CardNumber,@ExporationDate,@SecurityCode,@EDI,@ExportedAt,@Process_State)" +
								 " select IDENT_CURRENT('PaymentDetails')";
				using (SqlCommand Command = new SqlCommand(cmdText, Connection))
				{
					Connection.Open();
					Command.Parameters.AddWithValue("@CardOwner", O.CardOwner);
					Command.Parameters.AddWithValue("@CardNumber", O.CardNumber);
					Command.Parameters.AddWithValue("@ExporationDate", O.ExporationDate);
					Command.Parameters.AddWithValue("@SecurityCode", O.SecurityCode);
					Command.Parameters.AddWithValue("@EDI", O.EDI);
					Command.Parameters.AddWithValue("@EXportedAt", DateTime.Now);
					Command.Parameters.AddWithValue("@Process_State", O.Process_State);
					Command.Parameters.AddWithValue("@EventDate", DateTime.Now);
					var r = Command.ExecuteScalar();
					if (r != null)
					{
						int.TryParse(Convert.ToString(r), out Result);
					}
				}
			}
			return Result;
		}
		public static int Update(DAO.Test.PaymentDetails O)
		{
			int Result = -1;
			using (SqlConnection Connection = new SqlConnection(Connectionstring))
			{
				string cmdText = " update PaymentDetails set CardOwner=@CardOwner,CardNumber=@CardNumber,ExporationDate=@ExporationDate, " +
								 " SecurityCode=@SecurityCode,EDI=@EDI,EXportedAt=@EXportedAt,Process_State=@Process_State " +
								 " output 'UPD',@EventDate,deleted.PaymentDetailsID,deleted.CardOwner,deleted.CardNumber,deleted.ExporationDate, " +
								 " deleted.SecurityCode,deleted.EDI,deleted.EXportedAt,deleted.Process_State into Log_PaymentDetails(Event, EventDate, " +
								 " PaymentDetailsID, CardOwner, CardNumber, ExporationDate, SecurityCode, EDI, EXportedAt, Process_State) " +
								 " where PaymentDetailsID = @PaymentDetailsID";
				using (SqlCommand Command = new SqlCommand(cmdText, Connection))
				{
					Connection.Open();
					Command.Parameters.AddWithValue("@PaymentDetailsID", O.PaymentDetailsID);
					Command.Parameters.AddWithValue("@CardOwner", O.CardOwner);
					Command.Parameters.AddWithValue("@CardNumber", O.CardNumber);
					Command.Parameters.AddWithValue("@ExporationDate", O.ExporationDate);
					Command.Parameters.AddWithValue("@SecurityCode", O.SecurityCode);
					Command.Parameters.AddWithValue("@EDI", O.EDI);
					Command.Parameters.AddWithValue("@EXportedAt", DateTime.Now);
					Command.Parameters.AddWithValue("@Process_State", O.Process_State);
					Command.Parameters.AddWithValue("@EventDate", DateTime.Now);
					Result = Command.ExecuteNonQuery();
				}
			}
			return Result;
		}
		public static int Delete(DAO.Test.PaymentDetails O)
		{
			int Result = -1;
			using (SqlConnection Connection = new SqlConnection(Connectionstring))
			{
				string cmdText = " delete from  PaymentDetails  " +
								 " output 'DEL',@EventDate,deleted.PaymentDetailsID,deleted.CardOwner,deleted.CardNumber,deleted.ExporationDate, " +
								 " deleted.SecurityCode,deleted.EDI,deleted.EXportedAt,deleted.Process_State into Log_PaymentDetails(Event, EventDate, " +
								 " PaymentDetailsID, CardOwner, CardNumber, ExporationDate, SecurityCode, EDI, EXportedAt, Process_State) " +
								 " where PaymentDetailsID = @PaymentDetailsID";
				using (SqlCommand Command = new SqlCommand(cmdText, Connection))
				{
					Connection.Open();
					Command.Parameters.AddWithValue("@PaymentDetailsID", O.PaymentDetailsID);
					Command.Parameters.AddWithValue("@EDI", O.EDI);
					Command.Parameters.AddWithValue("@EXportedAt", DateTime.Now);
					Command.Parameters.AddWithValue("@Process_State", O.Process_State);
					Command.Parameters.AddWithValue("@EventDate", DateTime.Now);
					Result = Command.ExecuteNonQuery();
				}
			}
			return Result;
		}
		private static DAO.Test.PaymentDetails FillObject(System.Data.SqlClient.SqlDataReader record)
		{
			int PaymentDetailsID = record.GetInt32(record.GetOrdinal("PaymentDetailsID"));
			string CardOwner = record.GetString(record.GetOrdinal("CardOwner"));
			string CardNumber = record.GetString(record.GetOrdinal("CardNumber"));
			DateTime ExporationDate = record.GetDateTime(record.GetOrdinal("ExporationDate"));
			int SecurityCode = record.GetInt32(record.GetOrdinal("SecurityCode"));
			string EDI = record.GetString(record.GetOrdinal("EDI"));
			DateTime EXportedAt = record.GetDateTime(record.GetOrdinal("ExportedAt"));
			int Process_State = record.GetInt32(record.GetOrdinal("Process_State"));
			return new DAO.Test.PaymentDetails(PaymentDetailsID,CardOwner,CardNumber,ExporationDate,SecurityCode,EDI, EXportedAt, Process_State);
		}



	}
}
