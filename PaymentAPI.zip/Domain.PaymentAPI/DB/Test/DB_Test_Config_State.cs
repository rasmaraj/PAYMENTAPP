﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.PaymentAPI.DB.Test
{
    public class DB_Test_Config_State
    {

        public static Dictionary<int, string> Get()
        {
            var D = new Dictionary<int, string>();
            D.Add(0, "Error occurred due to known reason");
            D.Add(200, "Successfully created");
            D.Add(201, "Successfully updated");
            D.Add(202, "Successfully deleted");
            D.Add(400, "Rejected due to the carddetails holding with another owner");
            D.Add(401, "Rejected due to no change has been made");
            return D;
        }


    }
}
