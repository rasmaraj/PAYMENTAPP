﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.PaymentAPI.DAO.Test
{
   public class PaymentDetails
    {

        public int PaymentDetailsID { get; set; }
        public string CardOwner { get; set; }
        public string CardNumber { get; set; }
        public DateTime ExporationDate { get; set; }
        public int SecurityCode { get; set; }
        public string EDI { get; set; }
        public DateTime EXportedAt { get; set; }
        public int Process_State { get; set; }
        public PaymentDetails(int PaymentDetailsID, string CardOwner, string CardNumber, DateTime ExporationDate, int SecurityCode,string EDI,DateTime ExportedAt,int Process_State)
        {
            this.PaymentDetailsID = PaymentDetailsID;
            this.CardOwner = $"{CardOwner}".Trim();
            this.CardNumber =$"{CardNumber}".Trim() ;
            this.ExporationDate = ExporationDate;
            this.SecurityCode = SecurityCode;
            this.EDI =$"{EDI}".Trim() ;
            this.EXportedAt = ExportedAt;
            this.Process_State = Process_State;
        }

    }
}
