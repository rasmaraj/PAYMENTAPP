﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.PaymentAPI.Provider
{
   internal class Custom_SqlParameter
    {
        public static SqlParameter Get_Parameter(HashSet<int> ListofInput, string ParameterName)
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("IntegerValue",typeof(int));

            foreach (var s in ListofInput)
            {
                dt.Rows.Add(s);
            }
            return new SqlParameter()
            {
                ParameterName = ParameterName,
                SqlDbType = SqlDbType.Structured, // must be structured
                TypeName = "dbo.IntegerValues",
                Value = dt
            };

        }
    }
}
