﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationComponent.PaymentAPI.Model
{
   public class Model_Response
    {
        public int SuccessCount { get;  set; }
        public int FailureCount { get;  set; }
        public string ReferenceKey { get;  set; }
        public HashSet<string> FailureMessage { get;  set; }
        public Model.Model_BankCard SuccessResponse { get;  set; }
        
    }
}
