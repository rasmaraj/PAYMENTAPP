﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationComponent.PaymentAPI.Model
{
    public class Model_BankCard
    {
        public string PaymentDetailsID { get; set; }
        public string CardOwner { get; set; }
        public string CardNumber { get; set; }
        public string ExporationDate { get; set; }
        public string SecurityCode { get; set; }
        public Model_BankCard()
        {
        }

        public Model_BankCard(Domain.PaymentAPI.DAO.Test.PaymentDetails p)
        {
            if (p != null)
            {
                this.PaymentDetailsID = $"{p.PaymentDetailsID}";
                this.CardOwner = $"{p.CardOwner}";
                this.CardNumber = $"{Collect_Cardnumber(p.CardNumber)}";
                this.ExporationDate = $"{p.ExporationDate.ToString("MM/yyyy")}";
                this.SecurityCode = $"{p.SecurityCode}";
            }

        }

        private string Collect_Cardnumber(string cardNumber)
        {
            for (int i = 4; i <= cardNumber.Length; i += 4)
            {
                cardNumber = cardNumber.Insert(i, " ");
                i++;
            }
           return cardNumber.Trim();
        }


    }
}
