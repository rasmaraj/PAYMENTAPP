﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationComponent.PaymentAPI.Helper.Helper_Common
{
    internal class Helper_BankCard
    {
        public static string Collect_CardNumber(string cardNumber)
        {
            if (!string.IsNullOrWhiteSpace(cardNumber))
            {
                var s = "";
                foreach (var c in cardNumber)
                {
                    if (char.IsDigit(c))
                    {
                        s = $"{s}{c}";
                    }
                    else if (!char.IsWhiteSpace(c))
                    {
                        s = "";
                        break;
                    }
                }

                if (!string.IsNullOrWhiteSpace(s) && s.Length==16)
                {
                    return cardNumber;
                }
            }
            return "";
        }
        public static string Collect_SecurityNumber(string SecurityNumber)
        {
            if (!string.IsNullOrWhiteSpace(SecurityNumber))
            {
                if (SecurityNumber.All(char.IsDigit))
                {
                    int s = 0;
                    foreach (var c in SecurityNumber.ToCharArray())
                    {
                        if (char.IsDigit(c))
                        {
                            s = s + CharUnicodeInfo.GetDecimalDigitValue(c);
                        }
                    }
                    if ( s!= 0)
                    {
                        return SecurityNumber;
                    }
                }
            }
            return "";
        }
        public static string Collect_ExpiryDate(string ExpiryDate)
        {
            if (!string.IsNullOrWhiteSpace(ExpiryDate))
            {
                var L = ExpiryDate.ToCharArray();
                string _ExpiryDate = "";
                foreach(char c in L)
                {
                    _ExpiryDate = !char.IsDigit(c)? _ExpiryDate + '-' : _ExpiryDate + c;
                }
                if (_ExpiryDate.Length == 5)
                {

                    if (_ExpiryDate.IndexOf("-") > -1)
                    {
                        var E = _ExpiryDate.Split('-');
                        var E1 =Convert.ToString(E[0]).PadLeft(2, '0');
                        var E2 = Convert.ToString(E[1]).Length==2?"20"+Convert.ToString(E[1]): Convert.ToString(E[1]);
                        _ExpiryDate = E1 +"-"+ E2;
                    }
                   
                }
                if (_ExpiryDate.Length == 7)
                {
                    if (DateTime.TryParse("01-" + _ExpiryDate, out DateTime DT))
                    {
                        if (DT > DateTime.Now.Date)
                        {
                            return _ExpiryDate;
                        }
                    }

                }
            }
            return "";
        }
    }
}
