﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationComponent.PaymentAPI.Helper.Helper_Common
{
    public class Helper_GeneralSettings
    {
        public static string apiKey { get; private set; }
        public static string userName { get; private set; }
        public static string password { get; private set; }
        public static string Connectionstring { get; private set; }
        public static void Set_Settings(string _APIKey, string _userName, string _password)
        {
            apiKey = _APIKey;
            userName = _userName;
            password = _password;
        }
    }
}
