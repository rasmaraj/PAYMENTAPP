﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationComponent.PaymentAPI.Helper.Helper_DAL
{
    internal class Helper_DAL_Test_PaymentDetails
    {

        public static int Create(Domain.PaymentAPI.DAO.Test.PaymentDetails O, ref string referancekey)
        {
            O.CardNumber = GenerateCardNumber(O.CardNumber);
            var L = Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Get_ByCardNumber(O.CardNumber);
            bool valid = true;
            if (L.Count != 0)
            {
                valid = !Try_Exists(O,L, true);
            }
            if (valid)
            {
                int Key = Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Insert(O);
                if ( Key> 0)
                {
                    referancekey = $"{Key}";
                    return 200;
                }
            }
            return 400;
        }

        public static int update(Domain.PaymentAPI.DAO.Test.PaymentDetails O)
        {
            int Stage = 0;
            var L = Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Get_ByCardNumber(O.CardNumber);
            if (L.Count != 0)
            {
                var obj = L.FindAll(x => x.PaymentDetailsID==O.PaymentDetailsID).FirstOrDefault();
                if (obj != null && Collect_Key(obj).Equals(Collect_Key(O), StringComparison.OrdinalIgnoreCase))
                {
                    Stage= 401;
                }
                L = L.FindAll(x => x.PaymentDetailsID != O.PaymentDetailsID);
                if (L.Count != 0)
                {
                    if (L.FindAll(x =>x.ExporationDate>O.ExporationDate && (Collect_Key(x, true).Equals(Collect_Key(O, true), StringComparison.OrdinalIgnoreCase))).Count != 0)
                    {
                        Stage = 400;
                    }
                }
                if (Stage == 0)
                {
                    if (Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Update(O) > 0)
                    {
                        Stage = 201;
                    };
                }
            }

            return Stage;
        }


        public static int Delete(Domain.PaymentAPI.DAO.Test.PaymentDetails O)
        {
            var L = Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Get(new HashSet<int>() { O.PaymentDetailsID});
            if (L.Count != 0)
            {
                if (Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Delete(L.FirstOrDefault()) > 0)
                {
                    return 202;
                }
            }
            return 0;
        }
        public static bool Try_Exists(Domain.PaymentAPI.DAO.Test.PaymentDetails O,List<Domain.PaymentAPI.DAO.Test.PaymentDetails> L, bool Create)
        {

            bool Exits = false;         
            if (L.Count != 0)
            {
                if (L.FindAll(x => x.ExporationDate <= O.ExporationDate && (Collect_Key(x, true).Equals(Collect_Key(O, true), StringComparison.OrdinalIgnoreCase))).Count != 0)
                {
                    Exits = true;
                }
            }
            return Exits;
        }

        private static string Collect_Key(Domain.PaymentAPI.DAO.Test.PaymentDetails O, bool create = false)
        {
           

            if (!create)
            {
                return $"{O.PaymentDetailsID}{O.CardNumber}{O.CardOwner}{O.ExporationDate.ToString("MMyyyy")}{O.SecurityCode}";
            }


            return $"{O.CardNumber}{O.SecurityCode}";
        }

        private static string GenerateCardNumber(string _cardNumber)
        {
            string CardNumber = "";
            _cardNumber.ToList().ForEach(delegate (char c)
            {
                if (char.IsDigit(c))
                {
                    CardNumber = $"{CardNumber}{c}";
                }
            });
            return CardNumber;
        }

    }
}
