﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ApplicationComponent.PaymentAPI.Helper.Helper_PaymentAPI
{
    public class Helper_Controller_BankCardRegister
    {
        
        public static Model.Model_Response collectCard(string apiKey, object edi, string authHeader)
        {
            var Errors = new List<string>();
            var result = new Model.Model_Response();
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                if (!string.IsNullOrWhiteSpace(authHeader))
                {
                    var c = Helper_Common.Helper_GeneralSettings.apiKey;
                    if (validateAPIKey(apiKey, c, ref Errors))
                    {

                        if (validateAuthorizationKey(authHeader, ref Errors))
                        {
                            if (Errors.Count == 0)
                            {
                                var bankCard = collectBankCard(edi, ref Errors);
                                result.FailureCount = bankCard == null ? Errors.Count : 0;
                                result.FailureMessage = new HashSet<string>(Errors);
                                result.SuccessCount = bankCard == null ? 0 : 1;
                                if (bankCard != null)
                                {
                                    result.ReferenceKey = $"{bankCard.PaymentDetailsID}";
                                    bankCard.PaymentDetailsID = result.ReferenceKey;
                                }
                                result.SuccessResponse = bankCard == null ? null : bankCard;
                                return result;
                            }
                        }
                    }
                }
                else
                {
                    Errors.Add("Invalid autherization key!!");
                }
            }
            else
            {
                Errors.Add("Invalid Key!!");
            }
            result.FailureCount = Errors.Count;
            result.FailureMessage = new HashSet<string>(Errors);
            result.ReferenceKey = "";
            result.SuccessCount = 0;
            result.SuccessResponse = null;
            return result;
        }

        public static Model.Model_ResponseCollectAll collectAll(string apiKey,string authHeader)
        {
            var R = new Model.Model_ResponseCollectAll();
            var Errors = new List<string>();
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                if (!string.IsNullOrWhiteSpace(authHeader))
                {
                    var c = Helper_Common.Helper_GeneralSettings.apiKey;
                    if (validateAPIKey(apiKey, c, ref Errors))
                    {

                        if (validateAuthorizationKey(authHeader, ref Errors))
                        {
                            if (Errors.Count == 0)
                            {
                                var Result = collectAll(ref Errors);
                                R.SuccessCount = Result.Count;
                               R.SuccessResponse=Result;
                            }
                        }
                    }
                }
            }
            
            return R;
        }

        public static Model.Model_Response createCard(string apiKey, object edi, string authHeader)
        {
            var Errors = new List<string>();
            var result = new Model.Model_Response();
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                if (!string.IsNullOrWhiteSpace(authHeader))
                {
                    var c = Helper_Common.Helper_GeneralSettings.apiKey;
                    if (validateAPIKey(apiKey, c, ref Errors))
                    {

                        if (validateAuthorizationKey(authHeader, ref Errors))
                        {
                            if (Errors.Count == 0)
                            {
                                string ReferanceKey = "";
                                var bankCard = processBankCard(edi, ref Errors, ref ReferanceKey);
                                result.FailureCount = bankCard == null ? Errors.Count : 0;
                                result.FailureMessage = new HashSet<string>(Errors);
                                result.ReferenceKey = string.IsNullOrWhiteSpace(ReferanceKey) ? "" : ReferanceKey;
                                result.SuccessCount = bankCard == null ? 0 : 1;
                                if (bankCard != null)
                                {
                                    bankCard.PaymentDetailsID = ReferanceKey;
                                }
                                result.SuccessResponse = bankCard == null ? null : bankCard;
                                return result;
                            }
                        }
                    }
                }
                else
                {
                    Errors.Add("Invalid autherization key!!");
                }
            }
            else
            {
                Errors.Add("Invalid Key!!");
            }
            result.FailureCount = Errors.Count;
            result.FailureMessage = new HashSet<string>(Errors);
            result.ReferenceKey = "";
            result.SuccessCount = 0;
            result.SuccessResponse = null;
            return result;
        }


        public static Model.Model_Response updateCard(string apiKey, object edi, string authHeader)
        {
            var Errors = new List<string>();
            var result = new Model.Model_Response();
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                if (!string.IsNullOrWhiteSpace(authHeader))
                {
                    var c = Helper_Common.Helper_GeneralSettings.apiKey;
                    if (validateAPIKey(apiKey, c, ref Errors))
                    {

                        if (validateAuthorizationKey(authHeader, ref Errors))
                        {
                            if (Errors.Count == 0)
                            {
                               
                                var bankCard = updateBankCard(edi, ref Errors);
                                result.FailureCount = bankCard == null ? Errors.Count : 0;
                                result.FailureMessage = new HashSet<string>(Errors);
                                result.SuccessCount = bankCard == null ? 0 : 1;
                                if (bankCard != null)
                                {
                                    bankCard.PaymentDetailsID = bankCard.PaymentDetailsID;
                                }
                                result.SuccessResponse = bankCard == null ? null : bankCard;
                                return result;
                            }
                        }
                    }
                }
                else
                {
                    Errors.Add("Invalid autherization key!!");
                }
            }
            else
            {
                Errors.Add("Invalid Key!!");
            }
            result.FailureCount = Errors.Count;
            result.FailureMessage = new HashSet<string>(Errors);
            result.ReferenceKey = "";
            result.SuccessCount = 0;
            result.SuccessResponse = null;
            return result;
        }


        public static Model.Model_Response deleteCard(string apiKey, object edi, string authHeader)
        {
            var Errors = new List<string>();
            var result = new Model.Model_Response();
            if (!string.IsNullOrWhiteSpace(apiKey))
            {
                if (!string.IsNullOrWhiteSpace(authHeader))
                {
                    var c = Helper_Common.Helper_GeneralSettings.apiKey;
                    if (validateAPIKey(apiKey, c, ref Errors))
                    {

                        if (validateAuthorizationKey(authHeader, ref Errors))
                        {
                            if (Errors.Count == 0)
                            {

                                var bankCard = deleteBankCard(edi, ref Errors);
                                result.FailureCount = bankCard == null ? Errors.Count : 0;
                                result.FailureMessage = new HashSet<string>(Errors);
                                result.SuccessCount = bankCard == null ? 0 : 1;
                                if (bankCard != null)
                                {
                                    bankCard.PaymentDetailsID = bankCard.PaymentDetailsID;
                                }
                                result.SuccessResponse = bankCard == null ? null : bankCard;
                                return result;
                            }
                        }
                    }
                }
                else
                {
                    Errors.Add("Invalid autherization key!!");
                }
            }
            else
            {
                Errors.Add("Invalid Key!!");
            }
            result.FailureCount = Errors.Count;
            result.FailureMessage = new HashSet<string>(Errors);
            result.ReferenceKey = "";
            result.SuccessCount = 0;
            result.SuccessResponse = null;
            return result;
        }

        private static Model.Model_BankCard collectBankCard(object ID, ref List<string> Errors)
        {
            var EDI = Collect_EDI(ID, ref Errors);
            if (int.TryParse(Convert.ToString(EDI.PaymentDetailsID),out int paymentID))
            {
                var Ret = Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Get(new HashSet<int>() { paymentID }).FirstOrDefault();
                if (Ret != null)
                {
                    var M= new Model.Model_BankCard();
                    M.PaymentDetailsID = $"{Ret.PaymentDetailsID}";
                    M.CardNumber = $"{Ret.CardNumber}";
                    M.CardOwner = $"{Ret.CardOwner}";
                    M.SecurityCode = $"{Ret.SecurityCode}";
                    M.ExporationDate = $"{Ret.ExporationDate.ToString("MM/yyyy")}";
                    Errors.Add("Successfully retrived!!");
                    return M;
                }
                Errors.Add("No record found!!");
            }
            return null;
        }
        private static List<Model.Model_BankCard> collectAll(ref List<string> Errors)
        {
            var Result = new List<Model.Model_BankCard>();
            var Ret = Domain.PaymentAPI.DB.Test.DB_PaymentDetails.Get();
            if (Ret.Count != 0)
            {
                foreach (var r in Ret)
                {
                    Result.Add(new Model.Model_BankCard(r));
                }
            }
            return Result;
        }
        private static Model.Model_BankCard processBankCard(object edi, ref List<string> Errors, ref string referancekey)
        {

            var EDI = Collect_EDI(edi, ref Errors);
            if (EDI != null && Errors.Count == 0)
            {
                if (!ValidateBankCard(EDI, ref Errors))
                {
                    DateTime.TryParse("01-" + EDI.ExporationDate, out DateTime DT);
                    int.TryParse(EDI.SecurityCode, out int SC);
                    var O = new Domain.PaymentAPI.DAO.Test.PaymentDetails(0, EDI.CardOwner, EDI.CardNumber, DT, SC, Convert.ToString(edi), DateTime.Now, 0);
                    var Ret = Helper_DAL.Helper_DAL_Test_PaymentDetails.Create(O, ref referancekey);
                    if(Ret>-1)
                    {
                        if (Domain.PaymentAPI.DB.Test.DB_Test_Config_State.Get().TryGetValue(Ret, out string desc))
                        {
                            Errors.Add(desc);
                        }
                        if (Ret == 200)
                        {
                            return EDI;
                        }
                    }
                }
            }
            return null;
        }

        private static Model.Model_BankCard updateBankCard(object edi, ref List<string> Errors)
        {

            var EDI = Collect_EDI(edi, ref Errors);
            if (EDI != null && Errors.Count == 0)
            {
                if (!ValidateBankCard(EDI, ref Errors))
                {
                    DateTime.TryParse("01-" + EDI.ExporationDate, out DateTime DT);
                    int.TryParse(EDI.SecurityCode, out int SC);
                    if (int.TryParse(EDI.PaymentDetailsID, out int PaymentDetailsID) && PaymentDetailsID > 0)
                    {
                        var O = new Domain.PaymentAPI.DAO.Test.PaymentDetails(PaymentDetailsID, EDI.CardOwner, EDI.CardNumber, DT, SC, Convert.ToString(edi), DateTime.Now, 0);
                        var Ret = Helper_DAL.Helper_DAL_Test_PaymentDetails.update(O);
                        if (Ret > -1)
                        {
                            if (Domain.PaymentAPI.DB.Test.DB_Test_Config_State.Get().TryGetValue(Ret, out string desc))
                            {
                                Errors.Add(desc);
                            }
                            if (Ret == 201)
                            {
                                return EDI;
                            }
                        }
                    }
                    else
                    {
                        Errors.Add("Invalid Entry!!!");
                    }

                }
            }
            return null;
        }

        private static Model.Model_BankCard deleteBankCard(object edi, ref List<string> Errors)
        {

            var EDI = Collect_EDI(edi, ref Errors);
            if (EDI != null && Errors.Count == 0)
            {
                    DateTime.TryParse("01-" + EDI.ExporationDate, out DateTime DT);
                    int.TryParse(EDI.SecurityCode, out int SC);
                    if (int.TryParse(EDI.PaymentDetailsID, out int PaymentDetailsID) && PaymentDetailsID > 0)
                    {
                        var O = new Domain.PaymentAPI.DAO.Test.PaymentDetails(PaymentDetailsID, EDI.CardOwner, EDI.CardNumber, DT, SC, Convert.ToString(edi), DateTime.Now, 0);
                        var Ret = Helper_DAL.Helper_DAL_Test_PaymentDetails.Delete(O);
                        if (Ret > -1)
                        {
                            if (Domain.PaymentAPI.DB.Test.DB_Test_Config_State.Get().TryGetValue(Ret, out string desc))
                            {
                                Errors.Add(desc);
                            }
                            if (Ret == 202)
                            {
                                return EDI;
                            }
                        }
                    }
                    else
                    {
                        Errors.Add("Invalid Entry!!!");
                    }
            }
            return null;
        }

        #region Collect Model EDI
        private static Model.Model_BankCard Collect_EDI(object edi, ref List<string> Errors)
        {
            if (edi != null)
            {
                try
                {
                    return JsonConvert.DeserializeObject<Model.Model_BankCard>(Convert.ToString(edi));
                   
                }
                catch (Exception ex)
                {

                }
            }
            Errors.Add("Invalid JSon!!");
            return null;
        }
        #endregion

        #region Validate Keys

        private static bool validateAPIKey(string requestedKey, string apiKey, ref List<string> Errors)
        {

            if (!string.IsNullOrWhiteSpace(requestedKey) && requestedKey.Equals(apiKey, StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }
            Errors.Add("Invalid Key!!");
            return false;
        }

        private static bool validateAuthorizationKey(string authHeader, ref List<string> Errors)
        {

            try
            {
                string encodedUsernamePassword = authHeader.Substring("Basic ".Length).Trim();
                Encoding encoding = Encoding.GetEncoding("iso-8859-1");
                string usernamePassword = encoding.GetString(Convert.FromBase64String(encodedUsernamePassword));
                int seperatorIndex = usernamePassword.IndexOf(':');
                var _username = usernamePassword.Substring(0, seperatorIndex);
                var _password = usernamePassword.Substring(seperatorIndex + 1);
                if (!string.IsNullOrWhiteSpace(_username) && !string.IsNullOrWhiteSpace(_password))
                {
                    if (_username.Equals(Helper_Common.Helper_GeneralSettings.userName, StringComparison.OrdinalIgnoreCase) &&
                        _password.Equals(Helper_Common.Helper_GeneralSettings.password))
                    {
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
            }
            Errors.Add("Invalid autherization key!!");
            return false;
        }

        #endregion

        private static bool ValidateBankCard(Model.Model_BankCard B, ref List<string> ErrorList)
        {
            if (string.IsNullOrWhiteSpace(B.CardOwner))
            {
                ErrorList.Add("Invalid card name!!");
            }
            var cardNumber = Helper_Common.Helper_BankCard.Collect_CardNumber(B.CardNumber);
            if (string.IsNullOrWhiteSpace(cardNumber))
            {
                ErrorList.Add("Invalid card number!!");
            }
            string _securityCode = Helper_Common.Helper_BankCard.Collect_SecurityNumber(B.SecurityCode);
            if (string.IsNullOrWhiteSpace(_securityCode))
            {
                ErrorList.Add("Invalid security code!!");
            }
            string _ExpiryDate = Helper_Common.Helper_BankCard.Collect_ExpiryDate(B.ExporationDate);
            if (string.IsNullOrWhiteSpace(_ExpiryDate))
            {
                ErrorList.Add("Invalid expiry date!!");
            }
            if (ErrorList.Count != 0)
            {
                return true;
            }
            return false;
        }

    }
}
